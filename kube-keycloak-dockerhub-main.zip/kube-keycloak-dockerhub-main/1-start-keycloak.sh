kubectl apply -f common
sleep 1
kubectl apply -f postgres
sleep 1
kubectl apply -f keycloak
