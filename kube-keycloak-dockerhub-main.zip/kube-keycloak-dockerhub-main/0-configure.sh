#!/bin/bash

cd build
cd nginx
./0-build-image.sh
cd ..
cd ..
