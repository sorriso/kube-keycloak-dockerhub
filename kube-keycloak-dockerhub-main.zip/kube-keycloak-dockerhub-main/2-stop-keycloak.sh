kubectl delete -f keycloak
sleep 1
kubectl delete -f postgres
